/* eslint-disable
*/
import Trix from "trix/trix"

import "trix/core/helpers/global"
import "test/test_helper"

import "test/unit"
import "test/system"
