import "inspector/watchdog/recorder"
import "inspector/watchdog/player_element"

Trix.Watchdog = {}
