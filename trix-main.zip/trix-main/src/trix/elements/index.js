export { default as TrixEditorElement } from "trix_editor_element"
export { default as TrixToolbarElement } from "trix_toolbar_element"
