export const defer = (fn) => setTimeout(fn, 1)
